package clinicaDH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorioAlexisApplicationTests {

	@Test
	void contextLoads() {
	}

}

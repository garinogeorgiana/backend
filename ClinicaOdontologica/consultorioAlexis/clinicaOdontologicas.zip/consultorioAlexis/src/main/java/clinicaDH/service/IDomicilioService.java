package clinicaDH.service;

import clinicaDH.dto.DomicilioDto;

public interface IDomicilioService extends ICRUDService<DomicilioDto>{
    //podriamos poder metodos propios de la clase odontologos

    //metodo especifico de odontologo luego del
}

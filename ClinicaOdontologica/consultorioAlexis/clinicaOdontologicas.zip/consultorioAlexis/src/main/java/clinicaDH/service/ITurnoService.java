package clinicaDH.service;

import clinicaDH.dto.TurnoDto;

public interface ITurnoService extends ICRUDService<TurnoDto>{
}
